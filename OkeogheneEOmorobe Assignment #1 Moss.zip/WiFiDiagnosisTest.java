
public class WiFiDiagnosisTest {
	
	public static void main(String[] args) {
		  
		System.out.println("If you have a problem with internet connectivity, this WiFi Diagnosis might work.\n");
		  
		
		WiFiDiagnosis diagnosis = new WiFiDiagnosis();
		diagnosis.troubleShootWiFi();
		}
		

}
